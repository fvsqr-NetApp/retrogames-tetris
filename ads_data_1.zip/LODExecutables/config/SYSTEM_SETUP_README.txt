#################
# LAB PASSWORDS #
#################

All preconfigured passwords in the lab are set to "Netapp1!".

################
# LICENSE KEYS #
################

Base License:     UJBGVLVQJHOJKBAAAAAAAAAAAAAA 
  

Feature Licenses: (FlexClone, SnapManagerSuite, SnapRestore)

WSKAFTUTVEGEYAAAAAAAAAAAAAAA,GCETGTUTVEGEYAAAAAAAAAAAAAAA,YDPWDTUTVEGEYAAAAAAAAAAAAAAA 



