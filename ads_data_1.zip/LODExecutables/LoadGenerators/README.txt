The following load generation tools are available in this lab:

Iometer
IOzone
sio

Iometer is a graphical load generator that can be launched using the shortcuts found in
this folder. The installed Iometer package is Iometer-1.1.0, and the pdf manual for
IOmeter is also included in this folder.

Note: If you are having problems with IOmeter seeing mounted CIFS shares, the following
information may help. It appears that IOMeter won't "see" a share if the logged-in Windows
user account can't write to the root of the share. If you are experiencing this problem
it may be because this lab uses the UNIX root and Windows Administrator accounts for most
lab activities; if multi-protocol NAS access is not set up properly in Data ONTAP then
one or the other of these two accounts may not have write access to the namespace root.

The preferred solution is to set up root<->Administrator name mapping so that both accounts
are treated equivalently with regards to file access permissions. Another option is to look
at the security style setting for your SVM's root volume; if it is set to UNIX then try
switching it to NTFS instead, after which the Windows Administrator account should be able
to write to the root of the namespace. After you implement one of these solutions your
mounted shares should now be visible to IOmeter.

IOzone and sio are command line programs, so you must open a command prompt in order to
use them. From the command prompt issue "iozone -h" or "sio" to see each command's
respective usage information. A pdf manual for IOzone is also included in this folder.