Dummy File Creator(R) version 1.2
Copyright (C) 2008 Nikko Cheng
http://www.mynikko.com
All Rights Reserved

2008/05/17 - v1.2 Releasd : Improved random generation performance, supports batch generation
2002/12/04 - v1.1 Releasd : Minor interface change; added overwrite confirm dialog
2002/12/01 - v1.0.0.0 Released

Dummy File Creator, A simple program which creates files of any size with ease. Very useful for disk speed test, CD burning test, network speed test, or simply create files to fool your friends. This program also has a built-in random function, so users can choose to create either compressible or non-compressible files.

To Use, simply typing the desired file size (integer), and pick desired file location. Then click on "Create", and a file will be generated.