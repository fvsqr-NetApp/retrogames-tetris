Subject: 	README: LAB EMAIL


The admin@demo.netapp.com email address/account will only function inside
this lab. Email sent to this address through this email server
(mail.demo.netapp.com) from other hosts in this lab will be routed here,
provided those other systems are properly configured to process email.

Emails sent to a demo.netapp.com address from outside of this lab will not
be delivered here, or to anywhere else in this lab.

Emails sent from inside this lab to addresses outside of demo.netapp.com
will be accepted by this mail server, but they will not be delivered; they
will instead be silently discarded.